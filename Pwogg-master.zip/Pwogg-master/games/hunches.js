/**
 * Hunches game
 * Cassius - https://github.com/sirDonovan/Cassius
 *
 * @license MIT license
 */

'use strict';

const Room = require('./../rooms').Room; // eslint-disable-line no-unused-vars
const User = require('./../users').User; // eslint-disable-line no-unused-vars

const name = "Hunches";

/**@type {{[k: string]: Array<string>}} */
const data = {
	"Pokemon": [],
	"Pokemon Moves": [],
	"Pokemon Items": [],
	"Pokemon Abilities": [],
};

for (let i in Tools.data.pokedex) {
	let pokemon = Tools.data.pokedex[i];
	if (!pokemon.species) continue;
	data["Pokemon"].push(pokemon.species);
}

for (let i in Tools.data.moves) {
	let move = Tools.data.moves[i];
	if (!move.name) continue;
	data["Pokemon Moves"].push(move.name);
}

for (let i in Tools.data.items) {
	let item = Tools.data.items[i];
	if (!item.name) continue;
	data["Pokemon Items"].push(item.name);
}

for (let i in Tools.data.abilities) {
	let ability = Tools.data.abilities[i];
	if (!ability.name) continue;
	data["Pokemon Abilities"].push(ability.name);
}

class Hunches extends Games.Game {
	/**
	 * @param {Room} room
	 */
	constructor(room) {
		super(room);
		this.freeJoin = true;
		/**@type {Array<string>} */
		this.answers = [];
		/**@type {?NodeJS.Timer} */
		this.timeout = null;
		this.hint = '';
		this.points = new Map();
		this.maxPoints = 5;
		this.categories = Object.keys(data);
		this.currentCategory = '';
		this.guessLimit = 10;
		/**@type {Array<string>} */
		this.guessedLetters = [];
		/**@type {Array<string>} */
		this.solvedLetters = [];
		this.uniqueLetters = 0;
		this.roundGuesses = new Map();
	}

	onSignups() {
		this.timeout = setTimeout(() => this.nextRound(), 10 * 1000);
	}

	setAnswers() {
		let category;
		if (this.variation) {
			category = this.variation;
		} else {
			category = Tools.sample(this.categories);
		}
		this.currentCategory = category;
		let word = Tools.sample(data[category]);
		this.answers = [word];
		this.solvedLetters = [];
		this.guessedLetters = [];
		let letters = word.split("");
		this.letters = letters;
		let id = Tools.toId(word).split("");
		this.uniqueLetters = id.filter((letter, index) => id.indexOf(letter) === index).length;
		this.hint = [];
		for (let i = 0, len = Tools.toId(word).length; i < len; i++) {
			this.hint.push("");
		}
	}

	onNextRound() {
		if (this.timeout) this.timeout = null;
		if (!this.answers.length) this.setAnswers();
		this.roundGuesses.clear();
		let ended = false;
		if (this.guessedLetters.length >= this.guessLimit) {
			this.say("All guesses have been used! The answer was __" + this.answers[0] + "__");
			ended = true;
		} else if (this.solvedLetters.length >= this.uniqueLetters) {
			this.say("All letters have been revealed! The answer was __" + this.answers[0] + "__");
			ended = true;
		}
		if (ended) {
			this.answers = [];
			this.timeout = setTimeout(() => this.nextRound(), 5000);
			return;
		}
		for (let i = 0, len = this.letters.length; i < len; i++) {
			if (this.solvedLetters.includes(Tools.toId(this.letters[i]))) this.hint[i] = Tools.toId(this.letters[i]);
		}
		this.say("**[" + this.currentCategory + "]** " + this.hint.join("") + " | " + this.guessedLetters.join(", "));
	}

	/**
	 * @param {string} guess
	 */
	filterGuess(guess) {
		if (this.guessedLetters.includes(guess) || this.solvedLetters.includes(guess)) return true;
		return false;
	}

	/**
	 * @param {string} guess
	 */
	onGuess(guess) {
		if (!this.timeout) {
			this.timeout = setTimeout(() => this.nextRound(), 10 * 1000);
		}
		for (let i = 0, len = this.letters.length; i < len; i++) {
			if (Tools.toId(this.letters[i]) === guess) {
				if (!this.solvedLetters.includes(guess)) this.solvedLetters.push(guess);
				return;
			}
		}
		this.guessedLetters.push(guess);
	}
}

exports.name = name;
exports.id = Tools.toId(name);
exports.description = "Players guess letters to fill in the blanks and reveal the answers!";
exports.commands = {
	"guess": "guess",
	"g": "guess",
};
exports.variations = [
	{
		name: "Pokemon Hunches",
		variation: "Pokemon",
	},
	{
		name: "Move Hunches",
		aliases: ['Moves Hunches'],
		variation: "Pokemon Moves",
		variationAliases: ['moves'],
	},
	{
		name: "Item Hunches",
		aliases: ['Items Hunches'],
		variation: "Pokemon Items",
		variationAliases: ['items'],
	},
	{
		name: "Ability Hunches",
		aliases: ['Abilities Hunches'],
		variation: "Pokemon Abilities",
		variationAliases: ['abilities'],
	},
];
exports.modes = ["Team"];
exports.game = Hunches;

/**
 * @param {Hunches} game
 */
exports.spawnMochaTests = function (game) {
	if (game.modeId) return;

	const assert = require('assert');

	let tests = {
		/**
		 * @param {Hunches} game
		 */
		'guess': game => {
			game.signups();
			game.nextRound();
			MessageParser.parseCommand(Config.commandCharacter + 'guess ' + game.answers[0], game.room, Users.add("User 1"));
			assert(game.points.get(game.players['user1']) === 1);
		},
	};

	return tests;
};