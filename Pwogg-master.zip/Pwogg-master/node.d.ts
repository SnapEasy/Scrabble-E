declare namespace NodeJS {
	interface Global {
		Client: any
		Commands: any
		Config: any
		Games: any
		MessageParser: any
		Rooms: any
		Storage: any
		Tools: any
		Users: any
		toId: Function
    }
}
