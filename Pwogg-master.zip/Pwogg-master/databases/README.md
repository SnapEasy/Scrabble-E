# Databases

The Storage module uses this directory to store room databases in the .JSON format. It is not recommended to edit these files manually.
