'use strict';

exports.BattlePokeTeams = [
	["Red", "Blue"],
	["Gold", "Silver"],
	["Ruby", "Sapphire"],
	["Diamond", "Pearl"],
	["Black", "White"],
	["X", "Y"],
	["Sun", "Moon"],
];
