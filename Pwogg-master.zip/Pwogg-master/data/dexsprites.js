exports.sprites = {
	test: ['https://pldh.net/media/pokemon/gen6/xy-animated/201.gif'],
}